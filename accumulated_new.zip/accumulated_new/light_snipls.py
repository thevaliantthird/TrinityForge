"""
Lightweight SNIPLS — 365× smaller than full direpack pickle
==============================================================
Extracts only the 5 arrays needed for predict() and transform()
from a trained direpack.snipls model. Drops the stored training data
(X, y, scores, residuals) which cause the 45GB bloat.

Usage — saving after training:
    from direpack import snipls
    from light_snipls import LightSNIPLS

    model = snipls(eta=0.8, n_components=5)
    model.fit(X_train_scaled, y_train)

    # Extract lightweight version
    light = LightSNIPLS.from_direpack(model, feature_names=list(df.columns))
    light.save('usdsgd_h10.snipls')         # ~875 KB instead of ~3 GB

Usage — loading for inference:
    light = LightSNIPLS.load('usdsgd_h10.snipls')
    predictions = light.predict(X_scaled)    # same output as model.predict()
    features = light.transform(X_scaled)     # same output as model.transform()

Integration with general_model_new.py — replace the pickle.dump at the end:
    from light_snipls import save_all_models_light
    save_all_models_light(results, 'usdsgd_model_light.pickle', feature_names)

Storage comparison (16 ccys × 9 horizons = 144 models):
    Full direpack pickle:  ~45 GB
    LightSNIPLS:           ~123 MB  (365× smaller)
"""

import numpy as np
import pickle
from pathlib import Path


class LightSNIPLS:
    """
    Minimal representation of a trained SNIPLS model.
    Stores only the 5 arrays needed for predict() and transform().

    Attributes:
        coef_        (n_features, 1)            — regression coefficients
        intercept_   float                      — intercept
        x_Rweights_  (n_features, n_components) — rotation weights for transform
        x_loc_       (n_features,)              — centering vector for transform
        x_sca_       (n_features,)              — scaling vector for transform
        n_components int                        — number of PLS components
        n_features   int                        — expected input dimension
        feature_names list[str] or None         — column names (for alignment verification)
    """

    def __init__(self, coef_, intercept_, x_Rweights_, x_loc_, x_sca_,
                 n_components, n_features, feature_names=None):
        self.coef_ = np.asarray(coef_, dtype=np.float64)
        self.intercept_ = float(intercept_)
        self.x_Rweights_ = np.asarray(x_Rweights_, dtype=np.float64)
        self.x_loc_ = np.asarray(x_loc_, dtype=np.float64)
        self.x_sca_ = np.asarray(x_sca_, dtype=np.float64)
        self.n_components = int(n_components)
        self.n_features = int(n_features)
        self.feature_names = feature_names

    @classmethod
    def from_direpack(cls, model, feature_names=None):
        """
        Extract a LightSNIPLS from a trained direpack.snipls model.

        Args:
            model: trained direpack.snipls object
            feature_names: list of column names (optional, for alignment verification)
        """
        return cls(
            coef_=model.coef_,
            intercept_=model.intercept_,
            x_Rweights_=model.x_Rweights_,
            x_loc_=model.x_loc_,
            x_sca_=model.x_sca_,
            n_components=model.n_components,
            n_features=model.coef_.shape[0],
            feature_names=feature_names,
        )

    def predict(self, X):
        """
        Predict y from X. Identical to direpack snipls.predict().

        Args:
            X: (n_samples, n_features) array — ALREADY StandardScaler-transformed

        Returns:
            (n_samples, 1) array of predictions
        """
        X = np.asarray(X, dtype=np.float64)
        if X.ndim == 1:
            X = X.reshape(1, -1)
        if X.shape[1] != self.n_features:
            raise ValueError(
                f"Expected {self.n_features} features, got {X.shape[1]}. "
                f"Check column alignment with feature_registry.json."
            )
        return X @ self.coef_ + self.intercept_

    def transform(self, X):
        """
        Project X onto the latent components. Identical to direpack snipls.transform().

        Internally centers/scales X using the SNIPLS-internal centering (x_loc_, x_sca_)
        and then projects via x_Rweights_.

        Args:
            X: (n_samples, n_features) array — ALREADY StandardScaler-transformed

        Returns:
            (n_samples, n_components) array of latent scores
        """
        X = np.asarray(X, dtype=np.float64)
        if X.ndim == 1:
            X = X.reshape(1, -1)
        if X.shape[1] != self.n_features:
            raise ValueError(
                f"Expected {self.n_features} features, got {X.shape[1]}."
            )
        # Replicate direpack's scale_data(X, x_loc_, x_sca_)
        sca = self.x_sca_.copy()
        sca[sca == 0] = 1.0  # avoid division by zero
        X_centered = (X - self.x_loc_) / sca
        return X_centered @ self.x_Rweights_

    def save(self, path):
        """Save to a compact file."""
        data = {
            'coef_': self.coef_,
            'intercept_': self.intercept_,
            'x_Rweights_': self.x_Rweights_,
            'x_loc_': self.x_loc_,
            'x_sca_': self.x_sca_,
            'n_components': self.n_components,
            'n_features': self.n_features,
            'feature_names': self.feature_names,
        }
        with open(path, 'wb') as f:
            pickle.dump(data, f, protocol=pickle.HIGHEST_PROTOCOL)

    @classmethod
    def load(cls, path):
        """Load from a saved file."""
        with open(path, 'rb') as f:
            data = pickle.load(f)
        return cls(**data)

    def size_bytes(self):
        """Return the approximate in-memory size in bytes."""
        total = self.coef_.nbytes + self.x_Rweights_.nbytes
        total += self.x_loc_.nbytes + self.x_sca_.nbytes
        total += 8  # intercept
        return total

    def __repr__(self):
        return (f"LightSNIPLS(n_features={self.n_features}, "
                f"n_components={self.n_components}, "
                f"size={self.size_bytes()/1024:.0f}KB)")


def convert_model_pickle(input_path, output_path, feature_names=None):
    """
    Convert a full general_model_new.py output pickle to lightweight format.

    The input pickle has keys like 'output_h5_model', 'output_h10_model', etc.
    Each value is a trained direpack.snipls object.

    Args:
        input_path: path to the full pickle (e.g. usdsgd_model.pickle)
        output_path: path for the lightweight pickle
        feature_names: list of column names from the feather file
    """
    with open(input_path, 'rb') as f:
        full = pickle.load(f)

    light = {}
    for key, val in full.items():
        if key.endswith('_model'):
            light[key] = LightSNIPLS.from_direpack(val, feature_names=feature_names)
            print(f"  {key}: {light[key]}")
        else:
            # Keep scalar metrics as-is (they're tiny)
            light[key] = val

    with open(output_path, 'wb') as f:
        pickle.dump(light, f, protocol=pickle.HIGHEST_PROTOCOL)

    import os
    in_size = os.path.getsize(input_path)
    out_size = os.path.getsize(output_path)
    print(f"\n  {input_path}: {in_size/1024/1024:.1f} MB")
    print(f"  {output_path}: {out_size/1024/1024:.1f} MB")
    print(f"  Reduction: {in_size/out_size:.0f}×")


def save_all_models_light(results_dict, output_path, feature_names=None):
    """
    Drop-in replacement for the pickle.dump at the end of general_model_new.py.

    Instead of:
        with open(args.output_file, 'wb') as f:
            pickle.dump(results, f)

    Use:
        from light_snipls import save_all_models_light
        save_all_models_light(results, args.output_file, feature_names)

    This stores LightSNIPLS objects instead of full direpack models.
    """
    light = {}
    for key, val in results_dict.items():
        if key.endswith('_model'):
            light[key] = LightSNIPLS.from_direpack(val, feature_names=feature_names)
        else:
            light[key] = val

    with open(output_path, 'wb') as f:
        pickle.dump(light, f, protocol=pickle.HIGHEST_PROTOCOL)


# ═══════════════════════════════════════════════════════════════════
#  CLI: convert existing full pickles to lightweight
# ═══════════════════════════════════════════════════════════════════

if __name__ == '__main__':
    import argparse
    p = argparse.ArgumentParser(description="Convert full SNIPLS pickles to lightweight")
    p.add_argument("input", help="Full pickle (e.g. usdsgd_model.pickle)")
    p.add_argument("--output", help="Output path (default: input_light.pickle)")
    args = p.parse_args()

    output = args.output or args.input.replace('.pickle', '_light.pickle')
    print(f"Converting {args.input} → {output}")
    convert_model_pickle(args.input, output)
