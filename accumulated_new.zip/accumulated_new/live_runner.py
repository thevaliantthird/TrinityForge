"""
FX Live Trading Runner
=======================
Fetches Bloomberg data every 10 min, recomputes signal every 30 min,
tracks positions with TP/SL/timeout, persists trade history.

Usage:
    python live_runner.py
    python live_runner.py --dry-run --once
    python live_runner.py --fetch-interval 600 --signal-interval 1800
"""
import os, sys, time, json, pickle, logging, argparse, signal as sig, traceback
from pathlib import Path
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

# Shared code from init_live
from init_live import (
    CURRENCIES, INVERT_CCYS, HORIZONS, UNSAFE_PATTERNS,
    add_tech, get_neer_index, add_seasonal, build_feather, run_snipls,
)

FLAGS = {"AUD":"🇦🇺","CAD":"🇨🇦","CHF":"🇨🇭","CNH":"🇨🇳","EUR":"🇪🇺","GBP":"🇬🇧",
         "HKD":"🇭🇰","IDR":"🇮🇩","INR":"🇮🇳","JPY":"🇯🇵","KRW":"🇰🇷","MYR":"🇲🇾",
         "NZD":"🇳🇿","PHP":"🇵🇭","SGD":"🇸🇬","THB":"🇹🇭","TWD":"🇹🇼"}

def setup_logging():
    Path('logs').mkdir(exist_ok=True)
    log_file = f"logs/live_{datetime.now():%Y%m%d}.log"
    fmt = '%(asctime)s | %(levelname)-7s | %(funcName)-20s | %(message)s'
    logging.basicConfig(level=logging.DEBUG, format=fmt,
        handlers=[logging.FileHandler(log_file, encoding='utf-8'),
                  logging.StreamHandler(sys.stdout)])
    log = logging.getLogger('live')
    log.info(f"Log file: {log_file}")
    return log

# ═══════════════════════════════════════════════════════════════════
#  BLOOMBERG FETCHER
# ═══════════════════════════════════════════════════════════════════
class BloombergFetcher:
    def __init__(self, tickers, log):
        self.tickers = tickers; self.log = log; self._session = None
    def _connect(self):
        if self._session is not None: return
        try:
            import blpapi
            opts = blpapi.SessionOptions(); opts.setServerHost('localhost'); opts.setServerPort(8194)
            self._session = blpapi.Session(opts)
            if not self._session.start() or not self._session.openService("//blp/refdata"):
                raise ConnectionError("Bloomberg start/open failed")
            self.log.info(f"BLOOMBERG: connected, {len(self.tickers)} tickers registered")
        except ImportError:
            self.log.warning("BLOOMBERG: blpapi not installed — dry-run mode")
            self._session = 'DRY'
        except Exception as e:
            self.log.error(f"BLOOMBERG: connection error — {e}")
            self._session = 'DRY'
    def fetch(self):
        self._connect()
        if self._session == 'DRY':
            self.log.debug("BLOOMBERG: dry-run, returning empty"); return {}
        import blpapi
        t0 = time.time()
        svc = self._session.getService("//blp/refdata")
        req = svc.createRequest("ReferenceDataRequest")
        for t in self.tickers: req.getElement("securities").appendValue(t)
        req.getElement("fields").appendValue("PX_LAST")
        self._session.sendRequest(req)
        self.log.debug(f"BLOOMBERG: ReferenceDataRequest sent for {len(self.tickers)} tickers")
        prices = {}
        while True:
            ev = self._session.nextEvent(2000)
            for msg in ev:
                if msg.hasElement("securityData"):
                    sd = msg.getElement("securityData")
                    for i in range(sd.numValues()):
                        sec = sd.getValueAsElement(i)
                        tk = sec.getElementAsString("security")
                        fd = sec.getElement("fieldData")
                        if fd.hasElement("PX_LAST"):
                            prices[tk] = fd.getElementAsFloat("PX_LAST")
            if ev.eventType() == blpapi.Event.RESPONSE: break
        elapsed = time.time()-t0
        self.log.info(f"BLOOMBERG: fetched {len(prices)}/{len(self.tickers)} prices in {elapsed:.2f}s")
        if len(prices) < len(self.tickers):
            missing = set(self.tickers) - set(prices.keys())
            self.log.warning(f"BLOOMBERG: missing tickers: {sorted(missing)[:10]}")
        return prices

# ═══════════════════════════════════════════════════════════════════
#  POSITION TRACKER
# ═══════════════════════════════════════════════════════════════════
class Position:
    def __init__(self, entry_time, long_ccys, short_ccys, entry_prices, tp=30, sl=50, timeout_bars=96):
        self.entry_time=entry_time; self.long_ccys=long_ccys; self.short_ccys=short_ccys
        self.entry_prices=entry_prices; self.tp=tp; self.sl=sl; self.timeout_bars=timeout_bars
        self.bars_held=0; self.status='OPEN'; self.exit_reason=None; self.exit_time=None; self.current_pnl=0.0
    def update(self, current_prices):
        if self.status != 'OPEN': return None
        self.bars_held += 1
        l_pnl = np.mean([(current_prices.get(c,self.entry_prices.get(c,1))/self.entry_prices.get(c,1)-1)*10000
                          for c in self.long_ccys]) if self.long_ccys else 0
        s_pnl = np.mean([(1-current_prices.get(c,self.entry_prices.get(c,1))/self.entry_prices.get(c,1))*10000
                          for c in self.short_ccys]) if self.short_ccys else 0
        self.current_pnl = 0.5*l_pnl + 0.5*s_pnl
        if self.current_pnl >= self.tp:
            self.status='CLOSED'; self.exit_reason='TP'; self.exit_time=datetime.now()
            return f"🟢 TP +{self.current_pnl:.1f}bp"
        elif self.current_pnl <= -self.sl:
            self.status='CLOSED'; self.exit_reason='SL'; self.exit_time=datetime.now()
            return f"🔴 SL {self.current_pnl:.1f}bp"
        elif self.bars_held >= self.timeout_bars:
            self.status='CLOSED'; self.exit_reason='TO'; self.exit_time=datetime.now()
            return f"{'🟡' if self.current_pnl>0 else '🟠'} TO {self.current_pnl:+.1f}bp"
        return None

class PositionTracker:
    def __init__(self, tp=30, sl=50, timeout_bars=96, log=None):
        self.tp=tp; self.sl=sl; self.timeout_bars=timeout_bars; self.log=log
        self.open_positions=[]; self.closed_positions=[]; self.alerts=[]
        self.log_path = Path('logs')/'trade_history.csv'
        Path('logs').mkdir(exist_ok=True)
        if not self.log_path.exists():
            with open(self.log_path,'w') as f:
                f.write('entry_time,exit_time,exit_reason,pnl_bps,bars_held,long_ccys,short_ccys\n')
    def open_position(self, signal, prices):
        ep = {c: prices.get(c, 0) for c in signal['long']+signal['short']}
        pos = Position(signal['datetime'], signal['long'], signal['short'], ep, self.tp, self.sl, self.timeout_bars)
        self.open_positions.append(pos)
        if self.log:
            self.log.info(f"POSITION OPEN: L:{signal['long']} S:{signal['short']} "
                          f"prices: {json.dumps({k:round(v,5) for k,v in ep.items()})}")
        return pos
    def update_all(self, current_prices):
        alerts=[]; still_open=[]
        for pos in self.open_positions:
            old_pnl = pos.current_pnl
            alert = pos.update(current_prices)
            if self.log:
                self.log.debug(f"POSITION UPDATE: age={pos.bars_held} pnl={old_pnl:.2f}→{pos.current_pnl:.2f}")
            if alert:
                alerts.append(alert); self.alerts.append({'time':datetime.now(),'msg':alert})
                self.closed_positions.append(pos)
                with open(self.log_path,'a') as f:
                    f.write(f"{pos.entry_time},{pos.exit_time},{pos.exit_reason},"
                            f"{pos.current_pnl:.2f},{pos.bars_held},"
                            f"{';'.join(pos.long_ccys)},{';'.join(pos.short_ccys)}\n")
                if self.log:
                    self.log.info(f"POSITION CLOSED: {pos.exit_reason} pnl={pos.current_pnl:+.2f}bp "
                                 f"bars={pos.bars_held} L:{pos.long_ccys} S:{pos.short_ccys}")
            else: still_open.append(pos)
        self.open_positions = still_open; self.alerts = self.alerts[-20:]
        return alerts
    def summary(self):
        cl=self.closed_positions
        if not cl: return {'total':0,'wins':0,'pnl':0.0,'open':len(self.open_positions)}
        return {'total':len(cl),'wins':sum(1 for p in cl if p.current_pnl>0),
                'pnl':sum(p.current_pnl for p in cl),'open':len(self.open_positions)}
    def save_summary(self):
        s=self.summary(); s['date']=datetime.now().isoformat()
        s['tp']=sum(1 for p in self.closed_positions if p.exit_reason=='TP')
        s['sl']=sum(1 for p in self.closed_positions if p.exit_reason=='SL')
        s['to']=sum(1 for p in self.closed_positions if p.exit_reason=='TO')
        with open(Path('logs')/'session_summaries.jsonl','a') as f: f.write(json.dumps(s)+'\n')
    @staticmethod
    def load_history():
        p=Path('logs')/'trade_history.csv'
        return pd.read_csv(p,parse_dates=['entry_time','exit_time']) if p.exists() else pd.DataFrame()

# ═══════════════════════════════════════════════════════════════════
#  LIVE PIPELINE
# ═══════════════════════════════════════════════════════════════════
class LivePipeline:
    def __init__(self, config_dir='config', models_dir='models', data_dir='data',
                 log=None, dry_run=False):
        self.log = log or logging.getLogger('live')
        self.cfg_dir=Path(config_dir); self.mdl_dir=Path(models_dir); self.dat_dir=Path(data_dir)
        self.dry_run=dry_run; self.prev_scores=None; self.last_signal=None; self.last_bar_time=None
        self.tracker = PositionTracker(tp=30, sl=50, timeout_bars=96, log=self.log)
        self._signal_history = []
        self._load()

    def _load(self):
        t0 = time.time()
        self.log.info("─── LOADING ───")

        # Pickle
        pkl_path = self.dat_dir/'together_clean.pickle'
        self.log.info(f"Loading pickle: {pkl_path}")
        with open(pkl_path,'rb') as f: self.pkl = pickle.load(f)
        n_tickers = sum(len(tks) for tks in self.pkl.values())
        for fk in self.pkl:
            for tk in self.pkl[fk]: self.pkl[fk][tk] = self.pkl[fk][tk].astype(float)
        self.log.info(f"  Pickle: {len(self.pkl)} files, {n_tickers} tickers")

        # Desc
        self.descs = {}
        for ccy, cfg in CURRENCIES.items():
            dp = self.cfg_dir/cfg['desc']
            if dp.exists():
                with open(dp) as f: self.descs[ccy] = json.load(f)
        self.log.info(f"  Descs: {len(self.descs)} loaded")

        # SNIPLS models
        self.snipls = {}
        total_models = 0
        for ccy, cfg in CURRENCIES.items():
            mp = self.mdl_dir/cfg['model']
            if mp.exists():
                with open(mp,'rb') as f: self.snipls[ccy] = pickle.load(f)
                n = len([k for k in self.snipls[ccy] if '_model' in k])
                total_models += n
                self.log.debug(f"  {ccy} SNIPLS: {n} horizons ({mp.stat().st_size/1024:.0f} KB)")
        self.log.info(f"  SNIPLS: {len(self.snipls)} currencies, {total_models} models total")

        # Registry + scalers
        self.registry = None
        rp = self.dat_dir/'feature_registry.json'
        if rp.exists():
            with open(rp) as f: self.registry = json.load(f)
            self.log.info(f"  Registry: {len(self.registry.get('currencies',[]))} ccys, "
                          f"max_prov={self.registry.get('lambdamart_max_prov','?')}, "
                          f"n_features={self.registry.get('lambdamart_n_features','?')}")
        else:
            self.log.warning("  Registry: NOT FOUND — run init_live.py first!")

        self.scalers = {}
        sp = self.dat_dir/'scalers.pickle'
        if sp.exists():
            with open(sp,'rb') as f: self.scalers = pickle.load(f)
            self.log.info(f"  Scalers: {len(self.scalers)} loaded")
        else:
            self.log.warning("  Scalers: NOT FOUND — SNIPLS will refit each time")

        # LambdaMART
        import lightgbm as lgb
        lp = self.mdl_dir/'lambdamart.lgb'
        self.lmart = lgb.Booster(model_file=str(lp)) if lp.exists() else None
        if self.lmart:
            self.log.info(f"  LambdaMART: {self.lmart.num_trees()} trees from {lp}")
        else:
            self.log.error(f"  LambdaMART: NOT FOUND at {lp}")

        # Bloomberg fetcher
        all_tickers = set(cfg['ticker'] for cfg in CURRENCIES.values())
        for ccy in self.descs:
            for _, tks in self.descs[ccy].get('features_to_take',{}).items():
                all_tickers.update(tks)
        self.fetcher = BloombergFetcher(sorted(all_tickers), self.log)
        self.log.info(f"  Bloomberg: {len(all_tickers)} tickers registered")
        self.log.info(f"  Load complete in {time.time()-t0:.1f}s")

        # Fill the gap
        self._fill_gap()

    def _fill_gap(self):
        latest_ts = None
        for fk, tks in self.pkl.items():
            for tk, series in tks.items():
                ts = series.index.max()
                if latest_ts is None or ts > latest_ts: latest_ts = ts
        if latest_ts is None:
            self.log.warning("GAP FILL: no data in pickle"); return
        self.last_bar_time = pd.Timestamp(latest_ts)
        gap_hours = (datetime.now()-self.last_bar_time.to_pydatetime()).total_seconds()/3600
        self.log.info(f"GAP FILL: pickle ends at {self.last_bar_time}, gap={gap_hours:.1f}h ({gap_hours/0.5:.0f} bars)")
        if gap_hours < 0.5 or self.dry_run:
            self.log.info("GAP FILL: no gap to fill"); return
        try:
            import blpapi
            opts = blpapi.SessionOptions(); opts.setServerHost('localhost'); opts.setServerPort(8194)
            session = blpapi.Session(opts)
            if not session.start() or not session.openService("//blp/refdata"):
                self.log.warning("GAP FILL: Bloomberg unavailable"); return
            svc = session.getService("//blp/refdata")
            start_dt = self.last_bar_time.to_pydatetime()+timedelta(minutes=30)
            end_dt = datetime.now()
            all_tickers_in_pkl = {}
            for fk, tks in self.pkl.items():
                for tk in tks: all_tickers_in_pkl[tk] = fk
            bars_fetched = 0; tickers_done = 0
            for ticker in sorted(all_tickers_in_pkl):
                try:
                    req = svc.createRequest("IntradayBarRequest")
                    req.set("security",ticker); req.set("eventType","TRADE"); req.set("interval",30)
                    req.set("startDateTime",start_dt); req.set("endDateTime",end_dt)
                    session.sendRequest(req)
                    while True:
                        ev = session.nextEvent(2000)
                        for msg in ev:
                            if msg.hasElement("barData"):
                                bd = msg.getElement("barData").getElement("barTickData")
                                for i in range(bd.numValues()):
                                    bar = bd.getValueAsElement(i)
                                    ts = pd.Timestamp(bar.getElementAsDatetime("time"))
                                    px = bar.getElementAsFloat("close")
                                    fk = all_tickers_in_pkl[ticker]
                                    if ts not in self.pkl[fk][ticker].index:
                                        self.pkl[fk][ticker].loc[ts] = px; bars_fetched += 1
                        if ev.eventType() == blpapi.Event.RESPONSE: break
                    tickers_done += 1
                except Exception as e:
                    self.log.debug(f"GAP FILL: {ticker} error — {e}")
            for fk in self.pkl:
                for tk in self.pkl[fk]: self.pkl[fk][tk] = self.pkl[fk][tk].sort_index()
            # Update last_bar_time
            for fk, tks in self.pkl.items():
                for tk, series in tks.items():
                    ts = series.index.max()
                    if ts > self.last_bar_time: self.last_bar_time = pd.Timestamp(ts)
            self.log.info(f"GAP FILL: {bars_fetched} bars from {tickers_done} tickers, now ends at {self.last_bar_time}")
            session.stop()
        except ImportError:
            self.log.warning("GAP FILL: blpapi not available")
        except Exception as e:
            self.log.error(f"GAP FILL: failed — {e}"); self.log.debug(traceback.format_exc())

    def _append_live_bar(self, prices):
        now = datetime.now()
        bar_ts = pd.Timestamp(now.replace(minute=(now.minute//30)*30, second=0, microsecond=0))
        if self.last_bar_time and bar_ts <= self.last_bar_time:
            self.log.debug(f"BAR APPEND: {bar_ts} already exists, skipping"); return
        appended = 0
        for fk, tks in self.pkl.items():
            for tk in tks:
                if tk in prices:
                    self.pkl[fk][tk].loc[bar_ts] = prices[tk]
                    self.pkl[fk][tk] = self.pkl[fk][tk].sort_index()
                    appended += 1
        if appended > 0:
            self.last_bar_time = bar_ts
            self.log.info(f"BAR APPEND: {bar_ts} — {appended} tickers updated")

    def compute_signal(self):
        t0 = time.time()
        self.log.info("─── SIGNAL COMPUTATION ───")
        all_res = {}
        for ccy in sorted(CURRENCIES):
            if ccy not in self.descs or ccy not in self.snipls: continue
            tc = time.time()
            try:
                feather_df, feat_cols = build_feather(self.pkl, self.descs[ccy], self.log)
                if feather_df is None or len(feather_df) < 100:
                    self.log.warning(f"  {ccy}: insufficient data ({0 if feather_df is None else len(feather_df)} rows)")
                    continue
                # Use registry for column alignment
                reg_cols = None
                if self.registry and 'feather_columns' in self.registry:
                    reg_cols = self.registry['feather_columns'].get(ccy)
                    if reg_cols:
                        missing = [c for c in reg_cols if c not in feather_df.columns]
                        if missing:
                            self.log.error(f"  {ccy}: {len(missing)} registry cols missing! First 5: {missing[:5]}")
                            reg_cols = None
                        else:
                            self.log.debug(f"  {ccy}: registry aligned ({len(reg_cols)} cols)")
                use_cols = reg_cols if reg_cols else feat_cols

                # Use saved scaler or refit
                saved_scaler = self.scalers.get(ccy)
                if saved_scaler:
                    X = np.clip(feather_df[use_cols].values.astype(np.float64), -1e6, 1e6)
                    arr = saved_scaler.transform(X)
                    self.log.debug(f"  {ccy}: used saved scaler")
                    ticker = CURRENCIES[ccy]['ticker']
                    raw_price = feather_df[ticker]
                    price = 1.0/raw_price if ccy in INVERT_CCYS else raw_price
                    result = {'price': price}
                    for out_key in HORIZONS:
                        mk = f'{out_key}_model'
                        if mk not in self.snipls[ccy]: continue
                        model = self.snipls[ccy][mk]; h = int(out_key.split('h')[1])
                        pred = model.predict(arr); result[f'neer_predict_h{h}'] = pred.ravel() if pred.ndim>1 else pred
                        features = model.transform(arr)
                        for j in range(features.shape[1]): result[f'feature_{j+1}_h{h}'] = features[:,j]
                else:
                    result, _ = run_snipls(feather_df, use_cols, self.snipls[ccy], ccy, log=self.log)
                    self.log.debug(f"  {ccy}: refit scaler (no saved scaler)")

                all_res[ccy] = result
                nf = sum(1 for k in result if k.startswith('feature_'))
                self.log.info(f"  {ccy}: {len(feather_df)} rows, {nf} features, {time.time()-tc:.1f}s")
            except Exception as e:
                self.log.error(f"  {ccy}: FAILED — {e}"); self.log.debug(traceback.format_exc())

        if len(all_res) < 8:
            self.log.error(f"  Only {len(all_res)}/16 currencies processed — aborting signal"); return None
        ccys = sorted(all_res); nc = len(ccys)
        self.log.info(f"  {nc} currencies ready, building panel...")

        # Assemble panel
        indices = [all_res[c]['price'].index for c in ccys if isinstance(all_res[c]['price'], pd.Series)]
        common = indices[0]
        for ix in indices[1:]: common = common.intersection(ix)
        common = common.sort_values()
        self.log.debug(f"  Common index: {len(common)} bars [{common[0]} → {common[-1]}]")

        panel = {'Date': common}
        for ccy in ccys:
            r = all_res[ccy]
            if isinstance(r['price'], pd.Series): panel[f'{ccy}_price'] = r['price'].reindex(common).values
            for k, v in r.items():
                if k == 'price': continue
                if isinstance(v, pd.Series): panel[f'{ccy}_{k}'] = v.reindex(common).values
                elif isinstance(v, np.ndarray):
                    vf = v.ravel() if v.ndim>1 else v
                    if len(vf)==len(common): panel[f'{ccy}_{k}'] = vf
                    elif len(vf)>len(common): panel[f'{ccy}_{k}'] = vf[-len(common):]
        panel_df = pd.DataFrame(panel)
        for c in panel_df.columns:
            if c != 'Date': panel_df[c] = pd.to_numeric(panel_df[c], errors='coerce').ffill().bfill()

        # LambdaMART scoring
        safe = sorted([c for c in panel_df.columns if c!='Date' and not c.endswith('_price')
                       and not any(p in c.lower() for p in UNSAFE_PATTERNS)])
        temporal = np.column_stack([
            pd.to_datetime(panel_df['Date']).dt.dayofweek.values,
            pd.to_datetime(panel_df['Date']).dt.month.values,
            pd.to_datetime(panel_df['Date']).dt.year.values,
            pd.to_datetime(panel_df['Date']).dt.hour.values,
            pd.to_datetime(panel_df['Date']).dt.minute.values]).astype(np.float32)
        MAX_PROV = self.registry.get('lambdamart_max_prov',0) if self.registry else 0
        if MAX_PROV == 0: MAX_PROV = max(len([c for c in safe if c.startswith(ccy+'_')]) for ccy in ccys)

        X_last = []
        for j, ccy in enumerate(ccys):
            cs = sorted([c for c in safe if c.startswith(ccy+'_')])
            vals = panel_df[cs].iloc[-1].values.astype(np.float32)
            if len(vals) < MAX_PROV: vals = np.concatenate([vals, np.full(MAX_PROV-len(vals), np.nan)])
            X_last.append(np.concatenate([vals, temporal[-1], [float(j)]]))
        X_last = np.array(X_last, dtype=np.float32)
        self.log.debug(f"  LambdaMART input: {X_last.shape}, NaN={np.isnan(X_last).sum()}")

        if self.lmart is None:
            self.log.error("  No LambdaMART model loaded!"); return None
        scores = self.lmart.predict(X_last)
        rankings = np.argsort(scores)
        self.log.info(f"  Scores: {dict(zip(ccys, [round(float(s),3) for s in scores]))}")

        # Conviction gate
        from scipy.stats import spearmanr
        score_disp = float(np.std(scores))
        rank_stab = 0.0
        if self.prev_scores is not None and len(self.prev_scores)==len(scores):
            rank_stab, _ = spearmanr(np.argsort(scores), np.argsort(self.prev_scores))
            rank_stab = float(rank_stab)
        self.prev_scores = scores.copy()
        gate = rank_stab > 0.9 and score_disp > 0.05
        self.log.info(f"  Gate: disp={score_disp:.4f} stab={rank_stab:.3f} → {'🟢 FIRE' if gate else '⚪ skip'}")

        TOP_N=4; BOT_N=4
        long_ccys = [ccys[rankings[nc-1-i]] for i in range(TOP_N)]
        short_ccys = [ccys[rankings[i]] for i in range(BOT_N)]
        self.log.info(f"  Signal: LONG {long_ccys} | SHORT {short_ccys}")

        signal = {
            'datetime': str(panel_df['Date'].iloc[-1])[:19],
            'scores': {ccys[j]: round(float(scores[j]),4) for j in range(nc)},
            'long': long_ccys, 'short': short_ccys,
            'score_dispersion': round(score_disp,4),
            'rank_stability': round(rank_stab,4), 'gate_fired': gate,
            'rankings': {ccys[rankings[nc-1-i]]: i+1 for i in range(nc)},
        }
        self.last_signal = signal
        self.log.info(f"  Computation done in {time.time()-t0:.1f}s")
        return signal

    def display(self, signal):
        if not signal: return
        os.system('cls' if os.name=='nt' else 'clear')
        nc=len(signal['rankings']); W=72; now=datetime.now()
        gate='🟢 GATE FIRED — TRADE' if signal.get('gate_fired') else '⚪ Monitoring'
        print(f"╔{'═'*W}╗"); print(f"║{'FX PORTFOLIO RANKER — LIVE':^{W}}║"); print(f"╠{'═'*W}╣")
        print(f"║  Clock:  {now:%Y-%m-%d %H:%M:%S}{'':>{W-33}}║")
        print(f"║  Signal: {signal['datetime']}{'':>{W-33}}║")
        print(f"║  Status: {gate}{'':>{W-35}}║"); print(f"╠{'═'*W}╣")
        for side,key,icon in [('LONG','long','▲'),('SHORT','short','▼')]:
            print(f"║  {icon} {side} ({len(signal[key])}){'':>{W-len(side)-9}}║")
            for ccy in signal[key]:
                f=FLAGS.get(ccy,'  '); s=signal['scores'].get(ccy,0); r=signal['rankings'].get(ccy,'?')
                line=f"    {f} {ccy}  #{r:<3} score {s:>+.3f}"
                print(f"║{line}{'':>{W-len(line)}}║")
            print(f"║{'':>{W}}║")
        print(f"╠{'═'*W}╣")
        line=f"  Disp: {signal['score_dispersion']:.4f}  Stab: {signal['rank_stability']:.3f}  Gate: {'FIRE' if signal.get('gate_fired') else 'skip'}"
        print(f"║{line}{'':>{W-len(line)}}║"); print(f"╠{'═'*W}╣")
        sm=self.tracker.summary()
        line=f"  Open: {sm['open']}  Closed: {sm['total']}  Wins: {sm.get('wins',0)}  PnL: {sm.get('pnl',0):+.1f}bp"
        print(f"║{line}{'':>{W-len(line)}}║")
        for pos in self.tracker.open_positions[-3:]:
            age=pos.bars_held*10; astr=f"{age//60}h{age%60:02d}m" if age>=60 else f"{age}m"
            ic='↑' if pos.current_pnl>0 else '↓'
            line=f"    {ic} {pos.current_pnl:>+6.1f}bp  {astr:>5s}  L:{','.join(pos.long_ccys[:3])} S:{','.join(pos.short_ccys[:3])}"
            print(f"║{line}{'':>{W-len(line)}}║")
        if not self.tracker.open_positions:
            print(f"║  {'No open positions':}{'':>{W-21}}║")
        if self.tracker.alerts:
            print(f"╠{'═'*W}╣")
            for a in self.tracker.alerts[-3:]:
                line=f"  {a['time']:%H:%M} {a['msg']}"
                if len(line)>W-2: line=line[:W-4]+'..'
                print(f"║{line}{'':>{W-len(line)}}║")
        print(f"╠{'═'*W}╣")
        ranked=sorted(signal['rankings'].items(),key=lambda x:x[1])
        mid=(len(ranked)+1)//2
        for i in range(mid):
            c1,r1=ranked[i]; s1=signal['scores'].get(c1,0); f1=FLAGS.get(c1,'  ')
            t1=' ◄L' if r1<=4 else ' ◄S' if r1>=nc-3 else '   '
            col1=f"{r1:>2}. {f1} {c1} {s1:>+.3f}{t1}"; col2=''
            if i+mid<len(ranked):
                c2,r2=ranked[i+mid]; s2=signal['scores'].get(c2,0); f2=FLAGS.get(c2,'  ')
                t2=' ◄L' if r2<=4 else ' ◄S' if r2>=nc-3 else '   '
                col2=f"{r2:>2}. {f2} {c2} {s2:>+.3f}{t2}"
            line=f"  {col1}{'':>6}{col2}"
            print(f"║{line}{'':>{W-len(line)}}║")
        print(f"╠{'═'*W}╣")
        hist=PositionTracker.load_history()
        if not hist.empty:
            lt=len(hist); lw=(hist['pnl_bps']>0).sum(); lp=hist['pnl_bps'].sum()
            line=f"  Lifetime: {lt} trades  W:{lw} L:{lt-lw}  PnL:{lp:+.0f}bp"
            print(f"║{line}{'':>{W-len(line)}}║")
        line=f"  TP=30bp  SL=50bp  Hold≤2d  L4/S4"
        print(f"║{line}{'':>{W-len(line)}}║")
        print(f"╚{'═'*W}╝")
        print(f"  Refreshes every 10m | Next recompute ~{30-now.minute%30}m | Ctrl+C to stop")

    def _get_ccy_prices(self):
        cp = {}
        for ccy, cfg in CURRENCIES.items():
            tk = cfg['ticker']; fk = f"./updated/{cfg['file']}"
            if fk in self.pkl and tk in self.pkl[fk]:
                cp[ccy] = float(self.pkl[fk][tk].iloc[-1])
        return cp

    def run_loop(self, fetch_interval=600, signal_interval=1800):
        self.log.info(f"─── LIVE LOOP: fetch={fetch_interval}s signal={signal_interval}s ───")
        last_fetch=0; last_sig=0; running=[True]; latest_prices={}
        def handler(s,f): running[0]=False; self.log.info("SHUTDOWN requested")
        sig.signal(sig.SIGINT, handler); sig.signal(sig.SIGTERM, handler)
        # Initial signal
        self.log.info("Computing initial signal...")
        signal = self.compute_signal()
        if signal:
            self._signal_history.append(signal)
            if signal.get('gate_fired'):
                self.tracker.open_position(signal, self._get_ccy_prices())
            self.display(signal)
            with open('latest_signal.json','w') as f: json.dump(signal,f,indent=2)
        self.log.info("Entering main loop...")

        while running[0]:
            now = time.time()
            # Every 10 min: fetch + update positions + redraw
            if now - last_fetch >= fetch_interval:
                self.log.info(f"── 10-MIN TICK ({datetime.now():%H:%M:%S}) ──")
                try:
                    prices = self.fetcher.fetch()
                    if prices:
                        latest_prices = prices
                        cp = {ccy: prices[cfg['ticker']] for ccy, cfg in CURRENCIES.items() if cfg['ticker'] in prices}
                        if cp:
                            self.log.debug(f"  Updating {len(self.tracker.open_positions)} open positions")
                            alerts = self.tracker.update_all(cp)
                            for a in alerts: self.log.info(f"  ALERT: {a}")
                    if self.last_signal: self.display(self.last_signal)
                    last_fetch = now
                except Exception as e:
                    self.log.error(f"  10-min tick error: {e}"); self.log.debug(traceback.format_exc())

            # Every 30 min: append bar + recompute signal
            if now - last_sig >= signal_interval:
                self.log.info(f"── 30-MIN TICK ({datetime.now():%H:%M:%S}) ──")
                try:
                    if latest_prices:
                        self._append_live_bar(latest_prices)
                    signal = self.compute_signal()
                    if signal:
                        self._signal_history.append(signal)
                        if len(self._signal_history)>48: self._signal_history=self._signal_history[-48:]
                        if signal.get('gate_fired'):
                            self.tracker.open_position(signal, self._get_ccy_prices())
                        self.display(signal)
                        with open('latest_signal.json','w') as f: json.dump(signal,f,indent=2)
                    last_sig = now
                except Exception as e:
                    self.log.error(f"  30-min tick error: {e}"); self.log.debug(traceback.format_exc())
            time.sleep(10)

        self.log.info("─── SHUTDOWN ───")
        self.tracker.save_summary()
        self.log.info(f"Session summary saved. Final stats: {self.tracker.summary()}")

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config-dir", default="config")
    p.add_argument("--models-dir", default="models")
    p.add_argument("--data-dir", default="data")
    p.add_argument("--fetch-interval", type=int, default=600)
    p.add_argument("--signal-interval", type=int, default=1800)
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--once", action="store_true")
    args = p.parse_args()
    log = setup_logging()
    log.info("="*60); log.info("  FX LIVE RUNNER"); log.info(f"  Args: {vars(args)}"); log.info("="*60)
    pipe = LivePipeline(args.config_dir, args.models_dir, args.data_dir, log, args.dry_run)
    if args.once:
        signal = pipe.compute_signal()
        if signal: pipe.display(signal)
        with open('latest_signal.json','w') as f: json.dump(signal,f,indent=2)
    else:
        pipe.run_loop(args.fetch_interval, args.signal_interval)

if __name__ == "__main__":
    main()
