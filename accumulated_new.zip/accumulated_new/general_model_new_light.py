import numpy as np
import pandas as pd
import pickle
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score, mean_squared_error
from direpack import snipls
import argparse
import json
from light_snipls import LightSNIPLS


parser1 = argparse.ArgumentParser(description="General Model, Multiple pairs and NEERs")

parser1.add_argument("--feather", help="The feather file")
parser1.add_argument("--et", help="Alpha Factor")
parser1.add_argument("--num_component", help="Number of Compoents")
parser1.add_argument("--output_file", help="Output File")
parser1.add_argument("--desc_file", help="Description File")

args = parser1.parse_args()
# ────────────────────────────────────────────────
print('------------------------------------------------')
print(args.feather)
print('------------------------------------------------')

df = pd.read_feather(args.feather)

df = df.dropna()
scaler = StandardScaler()

feature_names = [x for x in df.columns if x.find('output') < 0]
index_to_col = {i: x for i, x in enumerate(feature_names)}
output_col_to_index = {x: i for i, x in enumerate([x for x in df.columns if x.find('output') >= 0])}


X = np.array(df[feature_names])
y = np.array(df[[x for x in df.columns if x.find('output') >= 0]])

X = np.clip(X, -1e6, 1e6)
y = np.clip(y, -1e6, 1e6)

train_size = int(0.65 * X.shape[0])
test_size = X.shape[0] - train_size

X_train = X[:(train_size), :]
y_train = y[:(train_size), :]

X_val = X[(train_size):, :]
y_val = y[(train_size):, :]

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_val_scaled = scaler.transform(X_val)
with open(args.desc_file, 'r') as f:
    parameters = json.load(f)
results = {}

global print_f
print_f = open(f"{args.feather}_output.txt", "w", encoding="utf-8")


def print_both(*args, **kwargs):
    print(*args, **kwargs)
    print(*args, **kwargs, file=print_f)


for col_name, diction in parameters.items():
    ind = output_col_to_index[col_name]

    print_both(f'Starting the Training_{col_name}')
    print_both('Y')
    print_both(np.std(y_train[:, ind]), np.mean(y_train[:, ind]))
    print_both(np.std(y_val[:, ind]), np.mean(y_val[:, ind]))

    yt_train = np.asarray(y_train[:, ind]).ravel()
    yt_val = np.asarray(y_val[:, ind]).ravel()

    et = float(diction['eta'])
    num_component = int(diction['n-component'])

    model1 = snipls(
        eta=et,
        n_components=num_component,
        verbose=False
    )

    model1.fit(X_train_scaled, yt_train)
    print_both('trained')

    loadings1 = model1.x_loadings_
    train_components1 = model1.x_scores_

    print_both('Model 1 Comps')
    selected_features = []
    for i in range(model1.n_components):
        nonzero_mask = np.abs(loadings1[:, i]) > 1e-6
        sel_idx = np.where(nonzero_mask)[0]
        selected_features.append(sel_idx)
        print_both(f"Component {i+1} ({model1.C_[i]}): {len(sel_idx)} / {X_train.shape[1]} features selected "
                   f"(sparsity: {100 * (1 - len(sel_idx)/X_train.shape[1]):.1f}%)")
        maximum_ind = np.argsort(np.abs(loadings1[:, i]))[::-1][:20]
        print_both([index_to_col[x] for x in maximum_ind])

    y_train_pred = model1.predict(X_train_scaled)
    y_val_pred = model1.predict(X_val_scaled)

    def correct_sign(y, y_pred):
        corr = np.sum(np.sign(y) == np.sign(y_pred[:, 0]))
        return corr / len(y)

    print_both("\nPerformance Diff:")
    print_both(f"Train   R²: {r2_score(yt_train, y_train_pred):.4f} | MSE: {mean_squared_error(yt_train, y_train_pred):.6f} | Sign: {correct_sign(yt_train, y_train_pred)}")
    print_both(f"Val     R²: {r2_score(yt_val,   y_val_pred):.4f}   | MSE: {mean_squared_error(yt_val,   y_val_pred):.6f}   | Sign: {correct_sign(yt_val,   y_val_pred)}")
    print_both('MEAN:')
    print_both(np.mean(yt_train), np.mean(y_train_pred))
    print_both(np.mean(yt_val), np.mean(y_val_pred))
    print_both('STD:')
    print_both(np.std(yt_train), np.std(y_train_pred))
    print_both(np.std(yt_val), np.std(y_val_pred))

    results[f'{col_name}_train_mean'] = np.mean(yt_train)
    results[f'{col_name}_train_pred_mean'] = np.mean(y_train_pred)
    results[f'{col_name}_val_mean'] = np.mean(yt_val)
    results[f'{col_name}_val_pred_mean'] = np.mean(y_val_pred)
    results[f'{col_name}_train_std'] = np.std(yt_train)
    results[f'{col_name}_train_pred_std'] = np.std(y_train_pred)
    results[f'{col_name}_val_std'] = np.std(yt_val)
    results[f'{col_name}_val_pred_std'] = np.std(y_val_pred)
    results[f'{col_name}_train_r2'] = r2_score(yt_train, y_train_pred)
    results[f'{col_name}_val_r2'] = r2_score(yt_val, y_val_pred)
    results[f'{col_name}_train_mse'] = mean_squared_error(yt_train, y_train_pred)
    results[f'{col_name}_val_mse'] = mean_squared_error(yt_val, y_val_pred)
    results[f'{col_name}_train_sign'] = correct_sign(yt_train, y_train_pred)
    results[f'{col_name}_val_sign'] = correct_sign(yt_val, y_val_pred)

    # ── Save lightweight model instead of full direpack object ──
    results[f'{col_name}_model'] = LightSNIPLS.from_direpack(model1, feature_names=feature_names)
    print_both(f'  → Saved as LightSNIPLS: {results[f"{col_name}_model"]}')


print_f.close()
with open(args.output_file, 'wb') as f:
    pickle.dump(results, f, protocol=pickle.HIGHEST_PROTOCOL)

import os
print(f'\nSaved: {args.output_file} ({os.path.getsize(args.output_file)/1024/1024:.1f} MB)')
