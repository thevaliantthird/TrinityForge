"""
FX Live System — Initialization
=================================
Builds the full feature pipeline, runs SNIPLS inference, trains LambdaMART.
Run once before live_runner.py, then daily to refresh.

Usage:
    python init_live.py
    python init_live.py --data-dir data/ --config-dir config/ --models-dir models/
"""
import os, sys, time, json, pickle, logging, argparse, traceback
from pathlib import Path
from datetime import datetime
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

# ═══════════════════════════════════════════════════════════════════
#  CONFIGURATION
# ═══════════════════════════════════════════════════════════════════
CURRENCIES = {
    'AUD': {'ticker':'AUDUSD BGN Curncy',  'file':'AUD.ods',  'model':'audusd_model.pickle', 'desc':'audusd_desc.json'},
    'CAD': {'ticker':'USDCAD BGN Curncy',  'file':'OTH.ods',  'model':'usdcad_model.pickle', 'desc':'usdcad_desc.json'},
    'CHF': {'ticker':'USDCHF BGN Curncy',  'file':'OTH.ods',  'model':'usdchf_model.pickle', 'desc':'usdchf_desc.json'},
    'CNH': {'ticker':'USDCNH BGN Curncy',  'file':'CNH.ods',  'model':'usdcnh_model.pickle', 'desc':'usdcnh_desc.json'},
    'EUR': {'ticker':'EURUSD BGN Curncy',  'file':'EUR.ods',  'model':'eurusd_model.pickle', 'desc':'eurusd_desc.json'},
    'GBP': {'ticker':'GBPUSD BGN Curncy',  'file':'GBP.ods',  'model':'gbpusd_model.pickle', 'desc':'gbpusd_desc.json'},
    'HKD': {'ticker':'USDHKD BGN Curncy',  'file':'HKD.ods',  'model':'usdhkd_model.pickle', 'desc':'usdhkd_desc.json'},
    'IDR': {'ticker':'IHN+1M BGN Curncy',  'file':'IDR.ods',  'model':'usdidr_model.pickle', 'desc':'usdidr_desc.json'},
    'INR': {'ticker':'IRN+1M BGN Curncy',  'file':'INR.ods',  'model':'usdinr_model.pickle', 'desc':'usdinr_desc.json'},
    'KRW': {'ticker':'KWN+1M BGN Curncy',  'file':'KRW.ods',  'model':'usdkrw_model.pickle', 'desc':'usdkrw_desc.json'},
    'MYR': {'ticker':'MRN+1M BBES Curncy', 'file':'MYR.ods',  'model':'usdmyr_model.pickle', 'desc':'usdmyr_desc.json'},
    'NZD': {'ticker':'NZDUSD BGN Curncy',  'file':'NZD.ods',  'model':'nzdusd_model.pickle', 'desc':'nzdusd_desc.json'},
    'PHP': {'ticker':'PPN+1M BGN Curncy',  'file':'PHP.ods',  'model':'usdphp_model.pickle', 'desc':'usdphp_desc.json'},
    'SGD': {'ticker':'USDSGD BGN Curncy',  'file':'SGD.ods',  'model':'usdsgd_model.pickle', 'desc':'usdsgd_desc.json'},
    'THB': {'ticker':'USDTHB BGN Curncy',  'file':'THB.ods',  'model':'usdthb_model.pickle', 'desc':'usdthb_desc.json'},
    'TWD': {'ticker':'NTN+1M BGN Curncy',  'file':'TWD.ods',  'model':'usdtwd_model.pickle', 'desc':'usdtwd_desc.json'},
}
INVERT_CCYS = {'AUD', 'NZD', 'EUR', 'GBP'}
HORIZONS = ['output_h5','output_h10','output_h15','output_h20','output_h30',
            'output_h40','output_h50','output_h80','output_h100']
UNSAFE_PATTERNS = ['neer_moves','actual_neer','returns','return_h','returns_h',
                   'fwd_','forward','target','output']

def setup_logging():
    Path('logs').mkdir(exist_ok=True)
    log_file = f"logs/init_{datetime.now():%Y%m%d_%H%M%S}.log"
    fmt = '%(asctime)s | %(levelname)-7s | %(funcName)-25s | %(message)s'
    logging.basicConfig(level=logging.DEBUG, format=fmt,
        handlers=[logging.FileHandler(log_file, encoding='utf-8'),
                  logging.StreamHandler()])
    log = logging.getLogger('init')
    log.info(f"Log file: {log_file}")
    return log

# ═══════════════════════════════════════════════════════════════════
#  FEATURE ENGINE (exact replica of get_final_dataset_new.py)
# ═══════════════════════════════════════════════════════════════════
def add_tech(p, col, windows=[5,10,20,50,100,200,400,800,1000,2000,3000]):
    new = {}; df = pd.DataFrame(p); df.columns = [col]
    for w in [2,3,4]+windows:
        sma = p.rolling(w).mean()
        new[f"{col}_sma_{w}"] = 2e4*(p-sma)/(p+sma)
        ema = p.ewm(span=w, adjust=False).mean()
        new[f"{col}_ema_{w}"] = 2e4*(p-ema)/(p+ema)
    for w in [2,3,4]+windows:
        new[f"{col}_roc_{w}"] = 1e2*p.pct_change(w)
        sma_ref = new.get(f"{col}_sma_{w}", p.rolling(w).mean())
        new[f"{col}_mom_{w}"] = 1e4*p.diff(w)/sma_ref
    for w in windows:
        std = p.rolling(w).std()
        new[f"{col}_std_{w}"] = std
        ema_ref = new.get(f"{col}_ema_{w}", p.ewm(span=w,adjust=False).mean())
        new[f"{col}_norm_{w}"] = 1e4*(p-ema_ref)/std
    for w in windows:
        for q in [0.10,0.25,0.50,0.75,0.90]:
            qv = p.rolling(w).quantile(q)
            new[f"{col}_{w}_rolling_q{int(q*100):02d}"] = 2e4*(p-qv)/(p+qv)
    _pv = p.dropna(); _pos = bool((_pv>0).all()) if len(_pv) else True
    r = (np.log(p).diff()*1e4) if _pos else (p.diff()*1e4)
    r2=r*r; absr=r.abs(); pos2=r2.where(r>0,0.0); neg2=r2.where(r<0,0.0)
    upb=(r>0).astype('float64'); med3=absr.rolling(3).median(); med3sq=med3*med3
    rlag=r.shift(1)
    prim={'rspos':pos2,'rsneg':neg2,'r3':r2*r,'r4':r2*r2,'absr':absr,
          'upfrac':upb,'medrv':med3sq,'acov':r*rlag,'r8sq':r.rolling(8).sum()**2}
    for w in [5,20,50,200,800,3000]:
        for _n,_g in prim.items(): new[f"{col}_{_n}_{w}"] = _g.rolling(w).mean()
    out = pd.concat([df, pd.DataFrame(new, index=p.index)], axis=1)
    _dead = [c for c in out.columns if out[c].isna().all() and c != col]
    return out.drop(columns=_dead) if _dead else out

def get_neer_index(df, col, neer):
    base = df[col].astype('float64')
    denom = pd.Series(1.0, index=df.index)
    for x, w in neer.items():
        if x in df.columns: denom *= df[x].astype('float64')**w
    return (base/denom).rename('price')

def add_seasonal(df, tz="Asia/Singapore"):
    idx = df.index
    if not isinstance(idx, pd.DatetimeIndex): return df
    aware = idx.tz_localize("UTC") if idx.tz is None else idx
    local = aware.tz_convert(tz).tz_localize(None)
    tod = (local.hour*60+local.minute)/(24*60)
    dow = local.dayofweek/7.0
    how = (local.dayofweek*24+local.hour+local.minute/60.0)/(7*24)
    dom = (local.day-1)/local.days_in_month
    moy = (local.month-1)/12.0
    d = local.normalize().values.astype("datetime64[D]")
    ms = local.to_period("M").to_timestamp().values.astype("datetime64[D]")
    nm = (local.to_period("M")+1).to_timestamp().values.astype("datetime64[D]")
    bdom = np.busday_count(ms, d)/np.maximum(np.busday_count(ms, nm), 1)
    harmonics = {"tod":[1,2,3,4,6,8],"dow":[1,2],"how":[1,2,3],
                 "dom":[1,2,3],"bdom":[1,2,3],"moy":[1,2,3]}
    phases = {"tod":np.asarray(tod),"dow":np.asarray(dow),"how":np.asarray(how),
              "dom":np.asarray(dom),"bdom":np.asarray(bdom),"moy":np.asarray(moy)}
    new = {}
    for name, phase in phases.items():
        ang = 2*np.pi*phase
        for k in harmonics.get(name,[]):
            new[f"seas_{name}_sin_{k}"] = np.sin(k*ang)
            new[f"seas_{name}_cos_{k}"] = np.cos(k*ang)
    return df.assign(**new)

# ═══════════════════════════════════════════════════════════════════
#  BUILD FEATHER + SNIPLS
# ═══════════════════════════════════════════════════════════════════
def build_feather(pickle_data, desc, log):
    orig_file = desc['original_file']; orig_ticker = desc['original_ticker']
    neer = desc['NEER']; feat_take = desc['features_to_take']
    fk = f'./updated/{orig_file}'
    if fk not in pickle_data or orig_ticker not in pickle_data[fk]:
        log.error(f"    MISSING: {orig_ticker} in pickle[{fk}]"); return None, None
    raw = pickle_data[fk][orig_ticker]
    log.debug(f"    Original: {orig_ticker}, {len(raw)} bars, "
              f"range [{raw.index.min()} → {raw.index.max()}], "
              f"last_px={raw.iloc[-1]:.6f}")
    final = add_tech(raw, orig_ticker)
    log.debug(f"    After own tech: {final.shape[1]} cols")
    n_ext = 0
    for file, tickers in feat_take.items():
        ffk = f'./updated/{file}'
        if ffk not in pickle_data:
            log.warning(f"    File {ffk} not in pickle, skipping"); continue
        for ticker in tickers:
            if ticker not in pickle_data[ffk]:
                log.warning(f"    Ticker {ticker} not in pickle[{ffk}], skipping"); continue
            feat = add_tech(pickle_data[ffk][ticker], ticker)
            final = final.join(feat, how='left'); n_ext += 1
    final = final.ffill().bfill()
    log.debug(f"    After {n_ext} external tickers: {final.shape[1]} cols")
    neer_col = f"{orig_ticker}_NEER"
    ni = get_neer_index(final, orig_ticker, neer)
    nf = add_tech(ni, neer_col)
    final = final.join(nf, how='left').ffill().bfill()
    log.debug(f"    After NEER: {final.shape[1]} cols")
    final = add_seasonal(final)
    log.debug(f"    After seasonal: {final.shape[1]} cols")
    for h in [5,10,15,20,30,40,50,80,100]:
        S = final[orig_ticker].astype('float64')
        fwd = S.shift(-1)[::-1].rolling(h, min_periods=1).mean()[::-1]
        val = 1e4*(fwd/S - 1.0)
        rho = 1e4*S.pct_change()
        for x, w in neer.items():
            if x in final.columns:
                Xc = final[x].astype('float64')
                Xf = Xc.shift(-1)[::-1].rolling(h, min_periods=1).mean()[::-1]
                val -= w*1e4*(Xf/Xc - 1.0); rho -= w*1e4*Xc.pct_change()
        sigma = np.sqrt((rho*rho).rolling(200, min_periods=50).mean())
        sigma = np.maximum(sigma, 0.5)
        final[f'output_h{h}'] = (val/sigma).values
    pre_drop = len(final)
    final = final.dropna()
    log.debug(f"    After dropna: {pre_drop} → {len(final)} rows ({pre_drop-len(final)} dropped)")
    feat_cols = [c for c in final.columns if 'output' not in c]
    nan_count = final[feat_cols].isna().sum().sum()
    log.debug(f"    Feature cols: {len(feat_cols)}, remaining NaN: {nan_count}")
    return final, feat_cols

def run_snipls(feather_df, feat_cols, model_pickle, ccy, scaler_frac=0.6, log=None):
    ticker = CURRENCIES[ccy]['ticker']
    X = np.clip(feather_df[feat_cols].values.astype(np.float64), -1e6, 1e6)
    n = len(X); train_end = int(n * scaler_frac)
    if log: log.debug(f"    Scaler: fit on rows [0:{train_end}], transform [{train_end}:{n}]")
    scaler = StandardScaler()
    arr = X.copy()
    arr[:train_end] = scaler.fit_transform(X[:train_end])
    arr[train_end:] = scaler.transform(X[train_end:])
    if log:
        log.debug(f"    Scaled X stats: mean={arr.mean():.4f} std={arr.std():.4f} "
                  f"min={arr.min():.2f} max={arr.max():.2f}")
    raw_price = feather_df[ticker]
    price = 1.0/raw_price if ccy in INVERT_CCYS else raw_price
    result = {'price': price}
    for out_key in HORIZONS:
        mk = f'{out_key}_model'
        if mk not in model_pickle:
            if log: log.warning(f"    {mk} not found in model pickle"); continue
        model = model_pickle[mk]
        h = int(out_key.split('h')[1])
        pred = model.predict(arr)
        pred_flat = pred.ravel() if pred.ndim > 1 else pred
        result[f'neer_predict_h{h}'] = pred_flat
        features = model.transform(arr)
        for j in range(features.shape[1]):
            result[f'feature_{j+1}_h{h}'] = features[:, j]
        if log:
            log.debug(f"    h{h}: predict mean={pred_flat.mean():.4f} std={pred_flat.std():.4f} | "
                      f"transform → {features.shape[1]} components")
    return result, scaler

# ═══════════════════════════════════════════════════════════════════
#  MAIN
# ═══════════════════════════════════════════════════════════════════
def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config-dir", default="config")
    p.add_argument("--models-dir", default="models")
    p.add_argument("--data-dir", default="data")
    p.add_argument("--train-frac", type=float, default=0.8)
    args = p.parse_args()
    log = setup_logging()
    log.info("="*60); log.info("  INIT LIVE"); log.info("="*60)
    log.info(f"  Args: {vars(args)}")
    t_all = time.time()
    cfg_dir = Path(args.config_dir); mdl_dir = Path(args.models_dir); dat_dir = Path(args.data_dir)
    for d in [cfg_dir, mdl_dir, dat_dir, Path('logs')]: d.mkdir(exist_ok=True)

    # ── 1. LOAD PICKLE ──
    log.info("─── STEP 1: Loading together_clean.pickle ───")
    pkl_path = dat_dir/'together_clean.pickle'
    if not pkl_path.exists():
        log.critical(f"MISSING: {pkl_path}"); sys.exit(1)
    pkl_size = pkl_path.stat().st_size / 1024 / 1024
    log.info(f"  File: {pkl_path} ({pkl_size:.1f} MB)")
    with open(pkl_path,'rb') as f: pkl = pickle.load(f)
    total_tickers = 0; total_bars = 0; latest_ts = None; earliest_ts = None
    for fk in pkl:
        for tk in pkl[fk]:
            pkl[fk][tk] = pkl[fk][tk].astype(float)
            total_tickers += 1; total_bars += len(pkl[fk][tk])
            ts_max = pkl[fk][tk].index.max(); ts_min = pkl[fk][tk].index.min()
            if latest_ts is None or ts_max > latest_ts: latest_ts = ts_max
            if earliest_ts is None or ts_min < earliest_ts: earliest_ts = ts_min
    log.info(f"  Files: {len(pkl)}, Tickers: {total_tickers}, Total bars: {total_bars:,}")
    log.info(f"  Date range: {earliest_ts} → {latest_ts}")
    for fk in sorted(pkl.keys()):
        tks = list(pkl[fk].keys())
        log.debug(f"  {fk}: {len(tks)} tickers — {tks[:5]}{'...' if len(tks)>5 else ''}")

    # ── 2. LOAD DESC + SNIPLS MODELS ──
    log.info("─── STEP 2: Loading desc files + SNIPLS models ───")
    descs = {}; models = {}
    for ccy, cfg in sorted(CURRENCIES.items()):
        dp = cfg_dir/cfg['desc']; mp = mdl_dir/cfg['model']
        desc_ok = dp.exists(); model_ok = mp.exists()
        if desc_ok:
            with open(dp) as f: descs[ccy] = json.load(f)
            n_neer = len(descs[ccy].get('NEER',{}))
            n_feat_files = len(descs[ccy].get('features_to_take',{}))
            n_feat_tickers = sum(len(v) for v in descs[ccy].get('features_to_take',{}).values())
            log.info(f"  {ccy}: desc=✓ (NEER:{n_neer} weights, {n_feat_files} files, {n_feat_tickers} tickers)")
        else:
            log.warning(f"  {ccy}: desc=✗ MISSING {dp}")
        if model_ok:
            t0 = time.time()
            with open(mp,'rb') as f: models[ccy] = pickle.load(f)
            n_models = len([k for k in models[ccy] if '_model' in k])
            model_size = mp.stat().st_size / 1024 / 1024
            horizons_found = [k.replace('_model','') for k in models[ccy] if '_model' in k]
            log.info(f"  {ccy}: model=✓ ({n_models} horizons: {horizons_found}, "
                     f"{model_size:.1f}MB, loaded in {time.time()-t0:.2f}s)")
        else:
            log.warning(f"  {ccy}: model=✗ MISSING {mp}")
    log.info(f"  Summary: {len(descs)} descs, {len(models)} models loaded")

    # ── 3. BUILD FEATHERS + RUN SNIPLS ──
    log.info("─── STEP 3: Building features + running SNIPLS ───")
    registry = {'feather_columns': {}, 'snipls_output_columns': {}, 'currencies': []}
    scalers = {}; all_res = {}

    for ccy in sorted(CURRENCIES):
        if ccy not in descs or ccy not in models:
            log.warning(f"  {ccy}: SKIPPING (missing desc or model)"); continue
        log.info(f"  ── {ccy} ──")
        t0 = time.time()
        try:
            feather_df, feat_cols = build_feather(pkl, descs[ccy], log)
            if feather_df is None:
                log.error(f"  {ccy}: build_feather returned None"); continue
            registry['feather_columns'][ccy] = feat_cols
            log.info(f"    Feather: {feather_df.shape[0]} rows × {len(feat_cols)} feat cols "
                     f"({feather_df.shape[1]} total with outputs)")

            result, scaler = run_snipls(feather_df, feat_cols, models[ccy], ccy, log=log)
            scalers[ccy] = scaler; all_res[ccy] = result
            registry['snipls_output_columns'][ccy] = sorted([k for k in result if k != 'price'])

            nf = sum(1 for k in result if k.startswith('feature_'))
            nn = sum(1 for k in result if k.startswith('neer_predict'))
            elapsed = time.time()-t0
            log.info(f"    SNIPLS: {nn} neer_predict + {nf} latent features ({elapsed:.1f}s)")

            # Sanity checks
            px = result['price']
            if isinstance(px, pd.Series):
                log.debug(f"    Price: last={px.iloc[-1]:.6f}, inverted={'yes' if ccy in INVERT_CCYS else 'no'}")
            for k, v in result.items():
                if k == 'price': continue
                v_arr = v.ravel() if isinstance(v, np.ndarray) and v.ndim > 1 else (v if isinstance(v, np.ndarray) else np.array([]))
                if len(v_arr) > 0:
                    nan_pct = np.isnan(v_arr).mean() * 100
                    if nan_pct > 0:
                        log.warning(f"    {ccy}_{k}: {nan_pct:.1f}% NaN!")
        except Exception as e:
            log.error(f"  {ccy}: FAILED — {e}")
            log.debug(traceback.format_exc())

    ccys = sorted(all_res); nc = len(ccys)
    registry['currencies'] = ccys
    registry['created'] = datetime.now().isoformat()
    log.info(f"  Completed: {nc}/{len(CURRENCIES)} currencies")

    # ── 4. ASSEMBLE PANEL ──
    log.info("─── STEP 4: Assembling panel ───")
    indices = [all_res[c]['price'].index for c in ccys if isinstance(all_res[c]['price'], pd.Series)]
    common = indices[0]
    for ix in indices[1:]: common = common.intersection(ix)
    common = common.sort_values()
    log.info(f"  Common index: {len(common)} bars [{common[0]} → {common[-1]}]")

    panel = {'Date': common}
    col_count = 0
    for ccy in ccys:
        r = all_res[ccy]
        if isinstance(r['price'], pd.Series):
            panel[f'{ccy}_price'] = r['price'].reindex(common).values; col_count += 1
        for k, v in r.items():
            if k == 'price': continue
            if isinstance(v, pd.Series):
                panel[f'{ccy}_{k}'] = v.reindex(common).values; col_count += 1
            elif isinstance(v, np.ndarray):
                vf = v.ravel() if v.ndim > 1 else v
                if len(vf) == len(common): panel[f'{ccy}_{k}'] = vf; col_count += 1
                elif len(vf) > len(common): panel[f'{ccy}_{k}'] = vf[-len(common):]; col_count += 1
                else: log.warning(f"  {ccy}_{k}: length {len(vf)} != common {len(common)}, SKIPPED")
    panel_df = pd.DataFrame(panel)
    for c in panel_df.columns:
        if c != 'Date': panel_df[c] = pd.to_numeric(panel_df[c], errors='coerce').ffill().bfill()
    nan_total = panel_df.isna().sum().sum()
    log.info(f"  Panel: {panel_df.shape} ({col_count} columns), NaN remaining: {nan_total}")
    panel_df.to_parquet(dat_dir/'panel.parquet')
    log.info(f"  Saved: {dat_dir/'panel.parquet'} ({(dat_dir/'panel.parquet').stat().st_size/1024/1024:.1f} MB)")

    # ── 5. TRAIN LAMBDAMART ──
    log.info("─── STEP 5: Training LambdaMART ───")
    import lightgbm as lgb
    nt = len(panel_df)
    prices = panel_df[[f"{c}_price" for c in ccys]].values.astype(np.float64)
    safe = sorted([c for c in panel_df.columns if c != 'Date' and not c.endswith('_price')
                   and not any(p in c.lower() for p in UNSAFE_PATTERNS)])
    log.info(f"  Safe columns: {len(safe)} (from {panel_df.shape[1]-1} total)")
    log.debug(f"  First 10 safe: {safe[:10]}")

    temporal = np.column_stack([
        pd.to_datetime(panel_df['Date']).dt.dayofweek.values,
        pd.to_datetime(panel_df['Date']).dt.month.values,
        pd.to_datetime(panel_df['Date']).dt.year.values,
        pd.to_datetime(panel_df['Date']).dt.hour.values,
        pd.to_datetime(panel_df['Date']).dt.minute.values]).astype(np.float32)
    MAX_PROV = max(len([c for c in safe if c.startswith(ccy+'_')]) for ccy in ccys)
    log.info(f"  MAX_PROV: {MAX_PROV} (widest currency's safe column count)")
    for ccy in ccys:
        n_ccy = len([c for c in safe if c.startswith(ccy+'_')])
        pad = MAX_PROV - n_ccy
        log.debug(f"    {ccy}: {n_ccy} safe cols{f' + {pad} padding' if pad > 0 else ''}")

    registry['lambdamart_max_prov'] = MAX_PROV
    registry['lambdamart_safe_cols'] = {ccy: sorted([c for c in safe if c.startswith(ccy+'_')]) for ccy in ccys}

    blocks = []
    for j, ccy in enumerate(ccys):
        cs = sorted([c for c in safe if c.startswith(ccy+'_')])
        pv = panel_df[cs].values.astype(np.float32)
        if pv.shape[1] < MAX_PROV:
            pv = np.hstack([pv, np.full((nt, MAX_PROV-pv.shape[1]), np.nan, dtype=np.float32)])
        blocks.append(np.column_stack([pv, temporal, np.full((nt,1),j,dtype=np.float32)]))
    nf = blocks[0].shape[1]
    registry['lambdamart_n_features'] = nf
    log.info(f"  LambdaMART features per obs: {nf} ({MAX_PROV} provided + 5 temporal + 1 ccy_id)")

    # Target
    fwd = np.full((nt,nc), np.nan, dtype=np.float32)
    for i in range(nt-96): fwd[i] = (prices[i+96]/prices[i]-1)*10000
    rr = np.zeros((nt,nc), dtype=np.float32)
    valid_targets = 0
    for i in range(nt):
        r = fwd[i]
        if not np.any(np.isnan(r)): o = np.argsort(r); rr[i,o] = np.arange(1,nc+1); valid_targets += 1
    log.info(f"  Target: {valid_targets}/{nt} bars have valid 96-bar forward returns")

    SK = 96; split = int(nt*args.train_frac); ne = nt-SK; sv = split-SK
    Xp = np.empty((ne*nc,nf),dtype=np.float32); yp = np.empty(ne*nc,dtype=np.float32)
    for j in range(nc): Xp[j::nc]=blocks[j][SK:]; yp[j::nc]=rr[SK:,j]
    qg = np.full(ne,nc,dtype=np.int32)
    log.info(f"  Train: {sv} groups ({sv*nc:,} rows), Test: {ne-sv} groups ({(ne-sv)*nc:,} rows)")

    # Walk-forward HP search
    HP = [{'lr':0.005,'nl':31,'md':4,'cb':0.4,'ra':0.5,'rl':2.0},
          {'lr':0.01,'nl':63,'md':6,'cb':0.5,'ra':0.3,'rl':1.5},
          {'lr':0.02,'nl':63,'md':6,'cb':0.4,'ra':0.1,'rl':1.0},
          {'lr':0.03,'nl':63,'md':6,'cb':0.3,'ra':0.1,'rl':1.0}]
    fsz = sv//4
    folds = [(0,fsz*(i+2),fsz*(i+2),min(fsz*(i+3),sv)) for i in range(2)]
    log.info(f"  HP search: {len(HP)} configs × {len(folds)} folds")
    for i, (_, te, vs, ve) in enumerate(folds):
        log.debug(f"    Fold {i}: train [0:{te}], val [{vs}:{ve}]")

    best_sc = -1; best_hp = HP[2]
    for ci, hp in enumerate(HP):
        sc = []
        for fi, (_,te,vs,ve) in enumerate(folds):
            try:
                m = lgb.train({'objective':'lambdarank','metric':'ndcg','eval_at':[1,3,5],
                    'learning_rate':hp['lr'],'num_leaves':hp['nl'],'max_depth':hp['md'],
                    'min_child_samples':50,'subsample':0.8,'colsample_bytree':hp['cb'],
                    'reg_alpha':hp['ra'],'reg_lambda':hp['rl'],
                    'lambdarank_truncation_level':10,'verbose':-1,'seed':42},
                    lgb.Dataset(Xp[:te*nc],yp[:te*nc],group=qg[:te]),300,
                    valid_sets=[lgb.Dataset(Xp[vs*nc:ve*nc],yp[vs*nc:ve*nc],group=qg[vs:ve])],
                    callbacks=[lgb.early_stopping(30)])
                ndcg = m.best_score['valid_0']['ndcg@5']
                sc.append(ndcg)
                log.debug(f"    HP{ci} fold{fi}: {m.best_iteration} trees, NDCG@5={ndcg:.4f}")
            except Exception as e:
                log.warning(f"    HP{ci} fold{fi}: FAILED — {e}")
        avg = np.mean(sc) if sc else 0
        log.info(f"  HP{ci}: lr={hp['lr']} nl={hp['nl']} md={hp['md']} cb={hp['cb']} → avg NDCG@5={avg:.4f}")
        if avg > best_sc: best_sc = avg; best_hp = hp
    log.info(f"  ★ Best: lr={best_hp['lr']} nl={best_hp['nl']} (NDCG@5={best_sc:.4f})")

    # Final model
    log.info("  Training final model...")
    model = lgb.train({'objective':'lambdarank','metric':'ndcg','eval_at':[1,3,5],
        'learning_rate':best_hp['lr'],'num_leaves':best_hp['nl'],'max_depth':best_hp['md'],
        'min_child_samples':50,'subsample':0.8,'colsample_bytree':best_hp['cb'],
        'reg_alpha':best_hp['ra'],'reg_lambda':best_hp['rl'],
        'lambdarank_truncation_level':10,'verbose':-1,'seed':42},
        lgb.Dataset(Xp[:sv*nc],yp[:sv*nc],group=qg[:sv]),1000,
        valid_sets=[lgb.Dataset(Xp[sv*nc:],yp[sv*nc:],group=qg[sv:])],
        callbacks=[lgb.early_stopping(80)])
    lm_path = mdl_dir/'lambdamart.lgb'
    model.save_model(str(lm_path))
    log.info(f"  LambdaMART: {model.best_iteration} trees → {lm_path}")
    log.info(f"  Final NDCG: {model.best_score}")

    # ── 6. SAVE EVERYTHING ──
    log.info("─── STEP 6: Saving artifacts ───")
    with open(dat_dir/'feature_registry.json','w') as f: json.dump(registry, f, indent=2)
    log.info(f"  feature_registry.json: {len(registry['currencies'])} ccys, "
             f"max_prov={registry['lambdamart_max_prov']}, n_features={registry['lambdamart_n_features']}")
    with open(dat_dir/'scalers.pickle','wb') as f: pickle.dump(scalers, f)
    log.info(f"  scalers.pickle: {len(scalers)} scalers")
    state = {'ccys':ccys,'n_features':nf,'max_prov':MAX_PROV,'best_hp':best_hp,
             'trees':model.best_iteration,'init_time':datetime.now().isoformat(),
             'latest_ts': str(latest_ts)}
    with open(dat_dir/'live_state.pickle','wb') as f: pickle.dump(state, f)
    log.info(f"  live_state.pickle: {json.dumps(state, default=str)}")

    log.info(f"\n{'━'*60}")
    log.info(f"  INITIALIZATION COMPLETE in {time.time()-t_all:.1f}s")
    log.info(f"  Panel: {panel_df.shape}")
    log.info(f"  Currencies: {ccys}")
    log.info(f"  LambdaMART: {model.best_iteration} trees, {nf} features/obs")
    log.info(f"  Next: python live_runner.py")
    log.info(f"{'━'*60}")

if __name__ == "__main__":
    main()
